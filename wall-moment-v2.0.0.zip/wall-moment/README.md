# Wall-moment reduction for switched heat transport

Code and numerical data accompanying **Boundary-operator-guided reduction for conservative and efficient switched heat transport**, by Zhenghang Wang, Baiying Dong and Tingfu Ma.

The channel has eight independently controlled Robin segments and two wall traces. The solver follows one temperature state through all eight segments and returns temperature fields, wall fluxes, bulk moments and integrated wall loads.

## Method

The package provides a **211-dimensional channel solver** and a **131-dimensional wall-moment construction**, with numerical operators, two channel inputs and the manuscript's channel comparison data.

- **Shared wall moments.** A velocity-dependent Schur mass metric reserves four directions for the first two wall-adjoint blocks. Twelve teacher directions complete the rank-131 construction.
- **Common-anchor propagation.** Two positive rank-one spectral updates recover each Robin segment from one anchor operator. The same state is carried across every switch.
- **Conservative wall loads.** The weak tests `1` and `y` recover both wall heat loads from modal moment decreases evaluated with `expm1`.

The supplied rank-211 operators store the enriched channel space. `run_inference.py` computes the two inputs in `data/cases.json`; `run_moments.py` constructs the rank-131 space from the supplied mother operators and teacher factors. `verify_results.py` checks the archived channel comparisons and raw timing records.

## Quick start

Use **Python 3.12**. From the extracted `wall-moment` directory:

```sh
python -m venv .venv
```

Activate the environment on Windows PowerShell:

```powershell
.venv\Scripts\Activate.ps1
```

Or on macOS/Linux:

```sh
source .venv/bin/activate
```

Then run:

```sh
python -m pip install -r requirements.txt
python verify_package.py
python run_inference.py --output results/channel
python run_moments.py
python -m unittest discover -s tests -v
python verify_results.py
python plot_results.py
```

The commands can also use `.venv\Scripts\python.exe` on Windows or `.venv/bin/python` on macOS/Linux directly. The default solver runs with the Python dependencies in `requirements.txt`.

`run_inference.py` checks temperature coefficients, wall flux, bulk moment, field reconstruction and segment heat against archived outputs. It also checks energy decay, discrete heat balance and agreement between weak and direct heat integration. Use `--output` to save computed arrays and diagnostics.

## Files

| File | Role |
| --- | --- |
| `wallmoment/model.py` | Channel parameters and reduced operators |
| `wallmoment/moments.py` | Schur mass complement, wall-moment protection and teacher compression |
| `wallmoment/solver.py` | Anchor spectrum, switched propagation and conservative heat loads |
| `wallmoment/secular.py` | Positive spectral updates through LAPACK DLAED9 |
| `wallmoment/arithmetic.py` | Portable split products and native compensated products |
| `wallmoment/io.py` | Input loading and archived-output checks |
| `native/compensated_dot.c` | AVX-512 arithmetic kernel |
| `data/channel_operators.npz` | Rank-211 operators and query grids |
| `data/moment_operators.npz` | Rank-147 mother operators and compressed teacher factors |
| `data/cases.json` | Inputs 748030003 (ID) and 748040003 (OOD) |
| `data/expected_outputs.npz` | Archived rank-211 solver outputs |
| `data/channel_comparisons.csv` | 2,400 channel comparison records |
| `data/timing_raw.csv` | 5,040 complete-call timings |
| `docs/method_map.md` | Correspondence between manuscript constructions and functions |
| `docs/verification.md` | Numerical checks and tolerances |
| `SHA256SUMS` | File-integrity checksums |

## Numerical backends

`portable` is the default. It evaluates compensated products using five 20-bit chunks and NumPy operations. `native` uses the AVX-512/FMA arithmetic kernel of the manuscript's channel calculation. Both use the same operators, mass factorization, anchor spectrum, segment updates and heat identities.

On an AVX512F/FMA3-capable machine with Clang installed:

```sh
python build_native.py --cc clang
python run_inference.py --backend native
```

On Windows, `lld-link` must be next to Clang or supplied with `--linker`. The kernel is compiled from `native/compensated_dot.c`. For the native test suite, set `WALLMOMENT_BACKEND=native` in the shell before running `unittest`.

The archived timing comparisons use the hardware and threading protocol described in [data/README.md](data/README.md). `verify_results.py` reconstructs their per-input medians from the recorded calls.

## Channel results

The comparison data cover **80 development inputs x 6 native comparators x 5 metrics**. `verify_results.py` checks every record and reconstructs the timing medians from nine repetitions per input and method. The largest proposed-to-comparator ratios are:

| Metric | Largest paired ratio |
| --- | ---: |
| Relative temperature-field error | 0.093758 |
| Relative all-age wall-flux error | 0.060647 |
| Relative segment-heat error | 0.462286 |
| Relative total-heat error | 0.901820 |
| Median complete-call time | 0.794689 |

Ratios below one favor the proposed solver. Field, flux and heat errors use the manuscript's reference-convergence policy. Timing ratios compare per-input medians. [data/README.md](data/README.md) defines the metrics, references and measurement protocol.

![Channel comparison ratios](channel_comparison.png)

Each point is the largest paired ratio over the six comparators for one input and one metric. Both input sets and all five metrics are shown; `plot_results.py` regenerates the figure from the CSV file.

## Citation

Please cite the accompanying manuscript when using the method or numerical data. Author and software metadata are provided in `CITATION.cff`.
