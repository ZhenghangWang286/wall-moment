"""Build the optional AVX-512 kernel with Clang."""

import argparse
from pathlib import Path
import shutil
import subprocess
import sys


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--cc", default="clang", help="Clang executable")
    parser.add_argument("--linker", default=None, help="lld-link executable on Windows")
    args = parser.parse_args()
    compiler = shutil.which(args.cc)
    if compiler is None:
        parser.error("Clang was not found; --backend portable requires no compiler")
    folder = Path(__file__).resolve().parent / "native"
    source = folder / "compensated_dot.c"
    flags = ["-O3", "-fno-fast-math", "-ffp-contract=off", "-fno-math-errno", "-mfma", "-mavx512f"]
    if sys.platform == "win32":
        linker = args.linker or str(Path(compiler).with_name("lld-link.exe"))
        obj, target = folder / "compensated_dot.obj", folder / "compensated_dot.dll"
        commands = [[compiler, *flags, "-ffreestanding", "-fno-builtin", "-c", str(source), "-o", str(obj)],
                    [linker, "/dll", "/noentry", "/nodefaultlib", "/export:compensated_dot",
                     f"/out:{target}", str(obj)]]
    else:
        target = folder / ("compensated_dot.dylib" if sys.platform == "darwin" else "compensated_dot.so")
        commands = [[compiler, *flags, "-shared", "-fPIC", str(source), "-o", str(target), "-lm"]]
    for command in commands:
        subprocess.run(command, check=True)
    print(f"Built {target.name}")


if __name__ == "__main__":
    main()
