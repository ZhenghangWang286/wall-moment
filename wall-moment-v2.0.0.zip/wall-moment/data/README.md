# Numerical data

All arrays use binary64 storage and are loaded with `allow_pickle=False`. Input records specify the physical parameters used by the solver.

## Operators and outputs

`channel_operators.npz` stores the 211-dimensional channel model:

- `mass0`, `massv`: the affine mass forms, with `M(s) = s*mass0 + (1-s)*massv`;
- `derivative_factor`: the square-root diffusion factor `D`;
- `walls`: the two trace rows `W`;
- `query`: evaluation of the basis at 888 transverse coordinates;
- `load0`, `loadv`: the mass loads for `1`, `y` and 24 sine inlet modes;
- `axial_grid`, `transverse_grid`: the 512-by-888 output grid.

`moment_operators.npz` contains the 147-dimensional mother operators, the teacher covariance factor and the field-and-trace metric factor used by the rank-131 construction. The covariance factor supplies compressed teacher information to `select_space`.

`cases.json` contains inputs **748030003** (ID) and **748040003** (OOD). Each has eight pairs of Robin coefficients, 24 inlet amplitudes, one diffusion parameter and one slip parameter. ID and OOD denote the diffusion ranges used in the manuscript.

`expected_outputs.npz` contains `{input_id}_coefficients`, `_q`, `_bulk` and `_heat`, recorded from the rank-211 channel calculation. `check_output` compares the computed arrays with these archived solver outputs. Field checks reconstruct the stored coefficients with the supplied query matrix. Reference-based error measurements are recorded in `channel_comparisons.csv`.

## Comparison records

`channel_comparisons.csv` contains 2,400 records for 80 development inputs, six native POD and rational comparators, and five metrics. The reference-resolution fields accompany the measured errors. Comparator names identify the POD and rational implementations and their respective dimensions.

Field and wall-flux errors use the manuscript's all-age quadrature and reference trajectories. Segment heat is a relative norm over the sixteen segment/wall loads. Total heat is the relative error in their sum. `seconds` is the median of nine complete calls for the same input and method.

The heat-reference policy combines converged Legendre references for 74 inputs with arbitrary-precision refinement for five close cases and one control. Reference convergence is assessed empirically through the manuscript's refinement diagnostics. Decimal fields store higher-precision values where available. `reference_policy` names the combined policy; `reference_precision`, `reference_order_lower` and `reference_order_upper` provide the available per-record refinement metadata.

## Timing records

`timing_raw.csv` contains **80 inputs x 7 methods x 9 calls = 5,040 timings**. The protocol used randomized interleaving on the recorded Windows CPU, a four-thread ceiling for native comparators and one BLAS thread for the proposed solver. Each call included parameter preparation, eight segments and the full field output. All 480 per-input median comparisons favor the proposed solver. The raw table stores every repetition for reconstruction of the medians and inspection of timing variation.

`verify_results.py` checks these recorded measurements and reconstructs their medians. `run_inference.py` computes the channel solutions with the selected arithmetic backend.

## Provenance

`provenance.json` records the manuscript and source-artifact hashes. `SHA256SUMS` at the package root covers the distributed files.
