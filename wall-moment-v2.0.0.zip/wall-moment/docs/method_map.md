# Manuscript-to-code correspondence

The implementation accompanies *Boundary-operator-guided reduction for conservative and efficient switched heat transport*.

| Manuscript construction | Implementation | Calculation |
| --- | --- | --- |
| Prescribed-velocity channel with eight Robin segments | `CoolingCase`, `Operators`, `segments` in `wallmoment/model.py` | `run_inference.py` |
| Schur mass complement | `_schur_mass_solver` in `wallmoment/moments.py` | `run_moments.py` |
| `X0 = M^-1 W^T`, `X1 = M^-1 D^T D X0` | `select_space` in `wallmoment/moments.py` | Four protected directions; first two output-moment identities checked in all eight segments |
| Covariance-ranked temperature complement | `select_space` and the supplied teacher/metric factors | Twelve teacher directions within rank 131 |
| Enriched conservative rank-211 realization | `data/channel_operators.npz` | Enriched operators with analytic assembly and the Neumann coordinate transformation |
| Refined thin triangular projections | `solve_case` in `wallmoment/solver.py` | One residual correction for the inlet and two trace right-hand sides |
| Common Robin anchor and nonnegative rank-one updates | `anchor_spectrum`, `positive_update` | One anchor spectrum and two wall updates per segment |
| Continuous state across switches | Modal propagation in `solve_case` | State continuity and Robin flux jumps tested at seven interior switches |
| Weak moment heat identities | `heat_from_moments` | Both wall loads from moment decreases using `-expm1(-h*rate)` |
| Independent modal wall integration | `direct_wall_heat` | Agreement with weak heat loads |

The rank-131 construction retains 115 protected modes, four wall-moment directions and twelve teacher directions. The rank-211 channel solver uses the enriched operators in `channel_operators.npz`, with one fixed space for both supplied inputs. It accepts valid parameter records through `CoolingCase`.

Numerical factors supply the offline information used by the online projection, propagation and output evaluation. `run_moments.py` builds the rank-131 space; `run_inference.py` computes the channel solutions. `verify_results.py` checks the recorded channel comparisons and timing data.
