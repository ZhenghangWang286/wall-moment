# Numerical verification

Run the structural and numerical checks from the package root:

```sh
python verify_package.py
python run_inference.py
python run_moments.py
python -m unittest discover -s tests -v
python verify_results.py
```

The test modules also support direct execution:

```sh
python tests/test_channel.py
python tests/test_structure.py
```

## Solver checks

The 18 tests cover archived-output agreement, mass positivity, finite fields, energy decay, heat balance, weak/direct heat integration, switch continuity, Robin flux jumps, endpoint conventions, parameter sensitivity, wall-moment identities, compensated arithmetic and rank-one spectral updates.

For inputs **748030003** and **748040003**, `check_output` compares the temperature coefficients, wall flux, bulk moment and segment heat with the archived rank-211 outputs. It reconstructs the field from the stored coefficients and query matrix. Array comparisons use `rtol=2e-11` and `atol=2e-13`.

The physical checks enforce:

- Relative agreement between weak and direct wall-heat integration below `1e-10`.
- Maximum discrete heat-balance residual below `1e-9`.
- Maximum segment energy increase at most `1e-12`.
- Common wall-moment residual below `1e-12` in each of the eight segments.
- State continuity across the seven interior switches and flux jumps consistent with the Robin coefficients.
- Parameter-dependent solutions: a changed Robin schedule changes the computed solution, while a changed input identifier preserves it.

The compensated-product test compares matrix products with exact rational accumulation. Spectral-update tests verify the matrix equation, orthogonality, zero updates and input validation.

Set `WALLMOMENT_BACKEND=native` to run the same tests with the compiled AVX-512/FMA kernel.

## Data checks

`verify_results.py` checks all **80 inputs x 6 comparators x 5 metrics** and reconstructs timing medians from the **5,040 recorded calls**. Every input/comparator/metric combination appears once; every input/method timing group contains nine distinct repetitions. The solver-output checks use the two inputs in `cases.json`; the comparison checks use the recorded measurements in the CSV files.

`plot_results.py` reads all 2,400 comparison records and displays the largest ratio over comparators for every input and metric. It writes PDF, SVG and PNG figures.

`verify_package.py` checks the distributed files against `SHA256SUMS`.
