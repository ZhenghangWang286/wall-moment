/* Compensated products with AVX-512 lanes. A is column-major; B and C
 * are row-major. Preserve floating-point operation order. */
#ifdef _WIN32
#define WALLMOMENT_EXPORT __declspec(dllexport)
#else
#define WALLMOMENT_EXPORT __attribute__((visibility("default")))
#endif
int _fltused=0;
typedef double v8d __attribute__((vector_size(64)));
typedef v8d unaligned_v8d __attribute__((aligned(1)));
#define ACCUMULATE(H,L,X,Y) do { \
    v8d p=(X)*(Y); v8d pe=__builtin_elementwise_fma((X),(Y),-p); \
    v8d s=(H)+p; v8d v=s-(H); v8d se=((H)-(s-v))+(p-v); \
    v8d e=((L)+pe)+se; v8d h=s+e; v8d w=h-s; \
    (L)=(s-(h-w))+(e-w); (H)=h; \
} while(0)

static double scalar(int rows,int inner,int cols,const double*a,const double*b,int i,int j){
    double hi=0.,lo=0.;
    for(int k=0;k<inner;k++){
        double x=a[k*rows+i],y=b[k*cols+j],p=x*y,pe=__builtin_fma(x,y,-p);
        double s=hi+p,v=s-hi,se=(hi-(s-v))+(p-v),e=(lo+pe)+se,h=s+e,w=h-s;
        lo=(s-(h-w))+(e-w);hi=h;
    }
    return hi+lo;
}

WALLMOMENT_EXPORT
void compensated_dot(int rows,int inner,int cols,const double*a,const double*b,double*out){
    if(rows<8 && cols>=8){
        for(int i=0;i<rows;i++){
            int j=0;
            for(;j+8<=cols;j+=8){
                v8d hi={0},lo={0};
                for(int k=0;k<inner;k++){
                    double av=a[k*rows+i];v8d x={av,av,av,av,av,av,av,av};
                    v8d y=*(const unaligned_v8d*)(b+k*cols+j);
                    ACCUMULATE(hi,lo,x,y);
                }
                *(unaligned_v8d*)(out+i*cols+j)=hi+lo;
            }
            for(;j<cols;j++)out[i*cols+j]=scalar(rows,inner,cols,a,b,i,j);
        }
        return;
    }
    int i=0;
    for(;i+16<=rows;i+=16){
        for(int j=0;j<cols;j++){
            v8d h0={0},l0={0},h1={0},l1={0};
            for(int k=0;k<inner;k++){
                double bv=b[k*cols+j];v8d y={bv,bv,bv,bv,bv,bv,bv,bv};
                v8d x0=*(const unaligned_v8d*)(a+k*rows+i);
                v8d x1=*(const unaligned_v8d*)(a+k*rows+i+8);
                ACCUMULATE(h0,l0,x0,y);ACCUMULATE(h1,l1,x1,y);
            }
            v8d o0=h0+l0,o1=h1+l1;
            for(int lane=0;lane<8;lane++){out[(i+lane)*cols+j]=o0[lane];out[(i+8+lane)*cols+j]=o1[lane];}
        }
    }
    for(;i+8<=rows;i+=8){
        for(int j=0;j<cols;j++){
            v8d hi={0},lo={0};
            for(int k=0;k<inner;k++){
                double bv=b[k*cols+j];v8d y={bv,bv,bv,bv,bv,bv,bv,bv};
                v8d x=*(const unaligned_v8d*)(a+k*rows+i);ACCUMULATE(hi,lo,x,y);
            }
            v8d value=hi+lo;for(int lane=0;lane<8;lane++)out[(i+lane)*cols+j]=value[lane];
        }
    }
    for(;i<rows;i++)for(int j=0;j<cols;j++)out[i*cols+j]=scalar(rows,inner,cols,a,b,i,j);
}
