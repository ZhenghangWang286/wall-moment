"""Plot the largest comparator ratio for each channel input and metric."""

import argparse
from collections import defaultdict
import csv
from pathlib import Path
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

ROOT = Path(__file__).resolve().parent
METRICS = [
    ("relative_field_l2", "Temperature field"),
    ("all_age_relative_wall_flux_l2", "Wall flux"),
    ("segment_heat_relative_l2", "Segment heat"),
    ("total_heat_relative_error", "Total heat"),
    ("seconds", "Median runtime"),
]


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, default=ROOT / "channel_comparison")
    args = parser.parse_args()
    with (ROOT / "data/channel_comparisons.csv").open(encoding="utf-8", newline="") as f:
        rows = list(csv.DictReader(f))
    groups = defaultdict(list)
    for row in rows:
        groups[row["metric"], row["split"], row["input_id"]].append(float(row["ratio"]))
    if len(rows) != 2400 or len(groups) != 400 or any(len(v) != 6 for v in groups.values()):
        raise ValueError("expected 80 inputs, six comparators and five metrics")
    if any(not np.isfinite(v).all() or min(v) <= 0 for v in groups.values()):
        raise ValueError("positive finite ratios required for the logarithmic axis")
    plt.rcParams.update({
        "font.family": "sans-serif", "font.sans-serif": ["DejaVu Sans"],
        "font.size": 9, "pdf.fonttype": 42, "svg.fonttype": "none",
        "axes.spines.top": False, "axes.spines.right": False,
        "axes.linewidth": 0.7, "legend.frameon": False,
    })
    fig, ax = plt.subplots(figsize=(183 / 25.4, 98 / 25.4))
    fig.subplots_adjust(left=0.215, right=0.96, bottom=0.20, top=0.81)
    for y, (metric, _) in enumerate(METRICS):
        for split, color, marker, offset in (("id", "#256D85", "o", -0.13),
                                              ("ood", "#BE6B35", "^", 0.13)):
            values = sorted(max(v) for (m, s, _), v in groups.items() if m == metric and s == split)
            if len(values) != 40:
                raise ValueError("expected 40 inputs in each set")
            # Offsets separate coincident points; they encode no measured quantity.
            offsets = (np.arange(len(values)) % 5 - 2) * 0.022
            ax.scatter(values, y + offset + offsets, s=15, c=color, marker=marker,
                       alpha=0.8, linewidths=0, label=split.upper() if y == 0 else None)
    ax.axvline(1.0, color="#666666", lw=0.9, ls=(0, (3, 3)))
    ax.set_xscale("log")
    ax.set_xlim(1e-5, 1.5)
    ax.set_ylim(4.5, -0.5)
    ax.set_yticks(range(5), [label for _, label in METRICS])
    ax.tick_params(axis="y", length=0, pad=8)
    ax.set_xlabel("Largest proposed / comparator ratio for each input", labelpad=9)
    ax.grid(axis="x", which="major", color="#dddddd", linewidth=0.5)
    ax.set_axisbelow(True)
    fig.text(0.215, 0.95, "Switched channel: all 80 inputs", fontsize=12, weight="bold")
    fig.text(0.215, 0.88, "Six native comparators per input; ratios below 1 favor the proposed solver", fontsize=8)
    handles, labels = ax.get_legend_handles_labels()
    fig.legend(handles, labels, loc="lower left", bbox_to_anchor=(0.20, 0.005),
               ncol=2, fontsize=8)
    fig.canvas.draw()
    args.output.parent.mkdir(parents=True, exist_ok=True)
    for extension in ("pdf", "svg", "png"):
        fig.savefig(args.output.with_suffix("." + extension), dpi=300)
    plt.close(fig)
    print(f"Saved {args.output.name}.pdf/.svg/.png from all 2400 rows")


if __name__ == "__main__":
    main()
