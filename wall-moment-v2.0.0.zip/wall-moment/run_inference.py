"""Propagate the two channel inputs and check the archived outputs."""

import argparse
import json
from pathlib import Path
import numpy as np
from wallmoment import solve_case
from wallmoment.io import DATA, check_output, load_cases
from wallmoment.solver import direct_wall_heat


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--backend", choices=("portable", "native"), default="portable")
    parser.add_argument("--output", type=Path, help="directory for computed arrays and diagnostics")
    args = parser.parse_args()
    operators, x, y, cases = load_cases()
    report = []
    if args.output:
        args.output.mkdir(parents=True, exist_ok=True)
    with np.load(DATA / "expected_outputs.npz", allow_pickle=False) as expected:
        for case in cases:
            result = solve_case(operators, case, x, backend=args.backend)
            difference = check_output(result, case, expected, operators)
            direct = direct_wall_heat(result["flux_modes"])
            gap = float(np.linalg.norm(direct - result["heat_integrals"]) / np.linalg.norm(direct))
            if gap >= 1e-10 or result["max_segment_energy_increase"] > 1e-12:
                raise ArithmeticError("physical checks failed")
            if result["max_discrete_balance"] >= 1e-9:
                raise ArithmeticError("discrete balance check failed")
            entry = dict(input_id=case.input_id, rank=operators.size, backend=args.backend,
                         max_absolute_difference=difference, weak_direct_heat_gap=gap,
                         balance_residual=result["max_discrete_balance"],
                         energy_increase=result["max_segment_energy_increase"])
            report.append(entry)
            print(f"{case.input_id}: rank {operators.size}; heat identity {gap:.3e}; PASS")
            if args.output:
                np.savez_compressed(args.output / f"{case.input_id}.npz", x=x, y=y,
                                    field=result["u"], wall_flux=result["q"],
                                    bulk=result["bulk"], segment_heat=result["heat_integrals"])
    if args.output:
        (args.output / "diagnostics.json").write_text(json.dumps(report, indent=2) + "\n")


if __name__ == "__main__":
    main()
