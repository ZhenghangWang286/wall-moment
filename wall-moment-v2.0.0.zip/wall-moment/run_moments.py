"""Check the two shared wall-moment orders in every Robin segment."""

import numpy as np
from scipy.linalg import cholesky, qr, solve_triangular
from threadpoolctl import threadpool_limits
from wallmoment import Operators
from wallmoment.io import DATA, load_cases
from wallmoment.moments import select_space


def moment_residuals(operators, projection, case):
    mass = case.slip * operators.mass0 + (1 - case.slip) * operators.massv
    factor = cholesky(mass, lower=True)
    retained, _ = qr(factor.T @ projection, mode="economic")
    discarded = np.eye(operators.size) - retained @ retained.T
    inverse = solve_triangular(factor, np.eye(operators.size), lower=True)
    residuals = []
    for biot in case.biot:
        stiffness = (operators.derivative_factor.T @ operators.derivative_factor
                     + operators.walls.T @ np.diag(biot) @ operators.walls)
        generator = case.epsilon * inverse @ stiffness @ inverse.T
        output = case.epsilon * np.diag(biot) @ operators.walls @ inverse.T
        residuals.append([np.linalg.norm(output @ discarded) / np.linalg.norm(output),
                          np.linalg.norm(output @ generator @ discarded) /
                          np.linalg.norm(output @ generator)])
    return np.asarray(residuals)


def main():
    with np.load(DATA / "moment_operators.npz", allow_pickle=False) as archive:
        operators = Operators.from_archive(archive)
        teacher, metric = archive["teacher_factor"], archive["metric_factor"]
    with threadpool_limits(limits=1):
        for case in load_cases()[3]:
            projection, info = select_space(operators, teacher, metric, case.slip)
            residual = moment_residuals(operators, projection, case)
            if residual.max() >= 1e-12:
                raise ArithmeticError("wall-moment identity failed")
            print(f"{case.input_id}: 147 -> 131; wall blocks {info['wall_moment_ranks']}; "
                  f"12 teacher directions; max residual {residual.max():.3e}; PASS")


if __name__ == "__main__":
    main()
