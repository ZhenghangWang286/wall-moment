import os
import sys
import unittest
from dataclasses import replace
from pathlib import Path
import numpy as np
from scipy.linalg import cholesky

if __name__ == "__main__":
    sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from wallmoment import solve_case
from wallmoment.io import DATA, check_output, load_cases
from wallmoment.model import segments
from wallmoment.solver import direct_wall_heat


class ChannelTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.backend = os.environ.get("WALLMOMENT_BACKEND", "portable")
        cls.operators, cls.x, cls.y, cls.cases = load_cases()
        cls.outputs = [solve_case(cls.operators, c, cls.x, cls.backend) for c in cls.cases]

    def test_archived_outputs(self):
        with np.load(DATA / "expected_outputs.npz", allow_pickle=False) as expected:
            for case, result in zip(self.cases, self.outputs):
                with self.subTest(input_id=case.input_id):
                    check_output(result, case, expected, self.operators)

    def test_mass_positive_definite(self):
        for slip in (0.1, 0.55, 1.0):
            matrix = slip * self.operators.mass0 + (1 - slip) * self.operators.massv
            np.testing.assert_allclose(matrix, matrix.T, atol=1e-14, rtol=1e-13)
            cholesky(matrix)

    def test_dimensions_and_finite_fields(self):
        for result in self.outputs:
            self.assertEqual(result["rank"], 211)
            self.assertEqual(result["u"].shape, (512, 888))
            self.assertEqual(result["heat_integrals"].shape, (8, 2))
            self.assertTrue(np.isfinite(result["u"]).all())

    def test_energy_decay_and_balance(self):
        for result in self.outputs:
            self.assertLessEqual(result["max_segment_energy_increase"], 1e-12)
            self.assertLess(result["max_discrete_balance"], 1e-9)

    def test_weak_and_direct_heat_agree(self):
        for result in self.outputs:
            direct = direct_wall_heat(result["flux_modes"])
            self.assertLess(np.linalg.norm(direct - result["heat_integrals"]) / np.linalg.norm(direct), 1e-10)

    def test_segment_heat_accounts_for_bulk_decrease(self):
        for case, result in zip(self.cases, self.outputs):
            bulk_test = case.slip * self.operators.load0[:, 0] + (1 - case.slip) * self.operators.loadv[:, 0]
            for mode, heat in zip(result["state_modes"], result["heat_integrals"]):
                change = -np.expm1(-mode["length"] * mode["rates"]) @ mode["amplitudes"] @ bulk_test
                self.assertAlmostEqual(float(heat.sum()), float(change), delta=2e-12)

    def test_state_continuity_at_switches(self):
        for result in self.outputs:
            modes = result["state_modes"]
            for previous, following in zip(modes[:-1], modes[1:]):
                end = np.exp(-previous["length"] * previous["rates"]) @ previous["amplitudes"]
                start = following["amplitudes"].sum(axis=0)
                np.testing.assert_allclose(start, end, rtol=2e-11, atol=2e-13)

    def test_flux_jumps_follow_robin_coefficients(self):
        for case, result in zip(self.cases, self.outputs):
            for j in range(7):
                state = np.exp(-0.125 * result["state_modes"][j]["rates"]) @ result["state_modes"][j]["amplitudes"]
                left = np.exp(-0.125 * result["flux_modes"][j]["rates"]) @ result["flux_modes"][j]["amplitudes"]
                right = result["flux_modes"][j + 1]["amplitudes"].sum(axis=0)
                jump = case.epsilon * (case.biot[j + 1] - case.biot[j]) * (self.operators.walls @ state)
                np.testing.assert_allclose(right - left, jump, rtol=1e-9, atol=1e-11)

    def test_switch_queries_use_left_segment(self):
        x = np.arange(1, 9) / 8
        case, result = self.cases[0], self.outputs[0]
        endpoint = solve_case(self.operators, case, x, self.backend)
        for j, mode in enumerate(result["flux_modes"]):
            target = np.exp(-mode["length"] * mode["rates"]) @ mode["amplitudes"]
            np.testing.assert_allclose(endpoint["q"][j], target, rtol=1e-10, atol=1e-12)

    def test_input_id_does_not_select_predictions(self):
        case = replace(self.cases[0], input_id=-1)
        result = solve_case(self.operators, case, self.x, self.backend)
        np.testing.assert_array_equal(result["coefficients"], self.outputs[0]["coefficients"])

    def test_new_schedule_changes_solution(self):
        case = replace(self.cases[0], biot=self.cases[0].biot * 1.1)
        result = solve_case(self.operators, case, self.x, self.backend)
        self.assertGreater(np.linalg.norm(result["q"] - self.outputs[0]["q"]), 1e-5)
        self.assertLessEqual(result["max_segment_energy_increase"], 1e-12)

    def test_invalid_inputs(self):
        for replacement in ({"epsilon": np.nan}, {"slip": 0.0}, {"biot": np.zeros((8, 2))},
                            {"inlet_modes": np.zeros(23)}):
            with self.assertRaises(ValueError):
                replace(self.cases[0], **replacement)
        for x in ([0.0, 0.5], [0.5, 0.5], [np.nan], [1.1], []):
            with self.assertRaises(ValueError):
                list(segments(self.cases[0].biot, x))


if __name__ == "__main__":
    unittest.main()
