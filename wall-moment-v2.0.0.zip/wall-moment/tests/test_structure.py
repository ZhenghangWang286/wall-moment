from fractions import Fraction
import os
import sys
import unittest
from pathlib import Path
import numpy as np
from threadpoolctl import threadpool_limits

if __name__ == "__main__":
    sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from wallmoment import Operators
from wallmoment.arithmetic import get_product
from wallmoment.io import DATA, load_cases
from wallmoment.moments import select_space
from wallmoment.secular import positive_update
from run_moments import moment_residuals
from verify_results import verify


class StructureTests(unittest.TestCase):
    def test_common_wall_moments_in_all_segments(self):
        with np.load(DATA / "moment_operators.npz", allow_pickle=False) as archive:
            operators = Operators.from_archive(archive)
            with threadpool_limits(limits=1):
                for case in load_cases()[3]:
                    projection, info = select_space(operators, archive["teacher_factor"],
                                                    archive["metric_factor"], case.slip)
                    self.assertEqual(projection.shape, (147, 131))
                    self.assertEqual(info["wall_moment_ranks"], [2, 2])
                    self.assertEqual(info["teacher_directions"], 12)
                    np.testing.assert_array_equal(projection[:115, :115], np.eye(115))
                    self.assertLess(moment_residuals(operators, projection, case).max(), 1e-12)

    def test_secular_update_against_matrix_equation(self):
        poles = np.array([0.001, 0.5, 1.0, 3.0, 20.0])
        for vector in (np.array([0.2, 0.0, -0.3, 0.1, 0.4]), np.ones(5)):
            values, basis = positive_update(poles, vector, 0.7)
            matrix = np.diag(poles) + 0.7 * np.outer(vector, vector)
            np.testing.assert_allclose(matrix @ basis, basis * values, rtol=1e-12, atol=1e-13)
            np.testing.assert_allclose(basis.T @ basis, np.eye(5), atol=1e-13)

    def test_zero_update_preserves_spectrum(self):
        poles = np.array([1.0, 2.0, 4.0])
        for rho, vector in ((0.0, np.ones(3)), (1.0, np.zeros(3))):
            values, basis = positive_update(poles, vector, rho)
            np.testing.assert_array_equal(values, poles)
            np.testing.assert_array_equal(basis, np.eye(3))

    def test_secular_input_validation(self):
        for poles, rho in (([1.0, 1.0], 1.0), ([1.0, 2.0], -1.0), ([1.0, np.nan], 1.0)):
            with self.assertRaises(ValueError):
                positive_update(poles, np.ones(2), rho)

    def test_compensated_products_against_exact_rationals(self):
        product = get_product(os.environ.get("WALLMOMENT_BACKEND", "portable"))
        rng = np.random.default_rng(113)
        a = rng.normal(size=(9, 41))
        b = rng.normal(size=(41, 10))
        a[:, 0] = 2.0**40
        a[:, 1] = -2.0**40
        b[1] = b[0]
        exact = np.array([[float(sum((Fraction(float(a[i, k])) * Fraction(float(b[k, j]))
                                     for k in range(41)), Fraction()))
                           for j in range(10)] for i in range(9)])
        np.testing.assert_allclose(product(a, b), exact, rtol=2e-15, atol=2e-15)
        scaled = product(np.ldexp(a, 400), np.ldexp(b, -400))
        np.testing.assert_allclose(scaled, exact, rtol=2e-15, atol=2e-15)

    def test_complete_comparison_and_timing_records(self):
        summary, repeat_wins = verify()
        self.assertEqual(len(summary), 5)
        self.assertEqual(sum(x["rows"] for x in summary.values()), 2400)
        self.assertEqual(repeat_wins, 4314)


if __name__ == "__main__":
    unittest.main()
