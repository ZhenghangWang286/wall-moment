"""Check the distributed files against SHA256SUMS."""

import hashlib
from pathlib import Path


def main():
    root = Path(__file__).resolve().parent
    entries = (root / "SHA256SUMS").read_text(encoding="utf-8").splitlines()
    for line in entries:
        expected, name = line.split("  ", 1)
        path = (root / name).resolve()
        if not path.is_relative_to(root):
            raise ValueError("checksum path escapes the package")
        actual = hashlib.sha256(path.read_bytes()).hexdigest()
        if actual != expected:
            raise AssertionError(f"checksum mismatch: {name}")
    print(f"{len(entries)} file checksums verified; PASS")


if __name__ == "__main__":
    main()
