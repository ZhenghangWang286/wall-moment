"""Check every archived channel comparison and reconstruct the timing medians."""

from collections import Counter, defaultdict
import csv
from pathlib import Path
import math
import statistics

DATA = Path(__file__).resolve().parent / "data"
BASELINES = {"original_pod113", "original_pod131", "original_pod139",
             "original_rational96", "original_rational132", "original_rational140"}
METRICS = {"relative_field_l2", "all_age_relative_wall_flux_l2",
           "segment_heat_relative_l2", "total_heat_relative_error", "seconds"}
PROPOSED = "ours_adjoint_neumann_triangular_r211"


def read_csv(name):
    with (DATA / name).open(encoding="utf-8", newline="") as stream:
        return list(csv.DictReader(stream))


def verify():
    rows = read_csv("channel_comparisons.csv")
    ids = {r["input_id"] for r in rows}
    expected_keys = {(i, b, m) for i in ids for b in BASELINES for m in METRICS}
    actual_keys = {(r["input_id"], r["baseline"], r["metric"]) for r in rows}
    if len(ids) != 80 or len(rows) != 2400 or actual_keys != expected_keys:
        raise AssertionError("the 80 x 6 x 5 comparison grid is incomplete")
    splits = {r["input_id"]: r["split"] for r in rows}
    if Counter(splits.values()) != {"id": 40, "ood": 40}:
        raise AssertionError("unexpected ID/OOD counts")
    groups = defaultdict(list)
    raw = read_csv("timing_raw.csv")
    for row in raw:
        value = float(row["seconds"])
        if not math.isfinite(value) or value <= 0:
            raise AssertionError("invalid timing value")
        groups[row["input_id"], row["method"]].append((int(row["repeat"]), value))
    if len(raw) != 5040 or set(groups) != {(i, m) for i in ids for m in BASELINES | {PROPOSED}}:
        raise AssertionError("the full timing grid is incomplete")
    if any(sorted(r for r, _ in g) != list(range(9)) for g in groups.values()):
        raise AssertionError("each case/method must have nine distinct repetitions")
    medians = {k: statistics.median(v for _, v in g) for k, g in groups.items()}
    summary = {}
    for metric in sorted(METRICS):
        metric_rows = [r for r in rows if r["metric"] == metric]
        ratios = []
        for row in metric_rows:
            proposed, baseline = float(row["proposed_value"]), float(row["baseline_value"])
            ratio = float(row["ratio"])
            if (not all(math.isfinite(v) for v in (proposed, baseline, ratio))
                    or not 0 <= proposed < baseline or not math.isclose(proposed / baseline, ratio, rel_tol=2e-14)):
                raise AssertionError("inconsistent comparison row")
            if metric == "seconds":
                pid = row["input_id"]
                if not (proposed == medians[pid, PROPOSED] and baseline == medians[pid, row["baseline"]]):
                    raise AssertionError("timing medians differ from the raw calls")
            ratios.append(ratio)
        summary[metric] = dict(rows=len(metric_rows), worst_ratio=max(ratios))
    repeat_wins = sum(dict(groups[i, PROPOSED])[r] < dict(groups[i, b])[r]
                      for i in ids for b in BASELINES for r in range(9))
    if repeat_wins != 4314:
        raise AssertionError("unexpected repeat-level timing count")
    return summary, repeat_wins


def main():
    summary, repeat_wins = verify()
    for metric, item in summary.items():
        print(f"{metric}: {item['rows']} pairs; largest ratio {item['worst_ratio']:.6f}")
    print(f"5040 raw calls checked; {repeat_wins}/4320 faster paired repetitions; PASS")


if __name__ == "__main__":
    main()
