"""Boundary-operator-guided reduction for switched heat transport."""

from .model import CoolingCase, Operators
from .solver import solve_case

__version__ = "2.0.0"
__all__ = ["CoolingCase", "Operators", "solve_case"]
