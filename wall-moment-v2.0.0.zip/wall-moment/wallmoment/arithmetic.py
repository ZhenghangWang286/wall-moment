"""Compensated matrix products for the thin projections and heat moments."""

import ctypes
from functools import lru_cache
from pathlib import Path
import sys
import numpy as np


def _check(a, b):
    a, b = np.asarray(a, dtype=float), np.asarray(b, dtype=float)
    if (a.ndim != 2 or b.ndim != 2 or a.shape[1] != b.shape[0]
            or min(*a.shape, *b.shape) == 0 or a.shape[1] >= 4096):
        raise ValueError("compatible nonempty matrices with inner dimension < 4096 required")
    if not np.isfinite(a).all() or not np.isfinite(b).all():
        raise ValueError("finite matrix entries required")
    return a, b


def portable_dot(a, b):
    """Accumulate products of five 20-bit chunks in decreasing order."""
    a, b = _check(a, b)
    ea = np.frexp(np.max(abs(a), axis=1))[1]
    eb = np.frexp(np.max(abs(b), axis=0))[1]
    aa, bb = np.ldexp(a, -ea[:, None]), np.ldexp(b, -eb[None, :])
    parts_a, parts_b = [], []
    for _ in range(5):
        ca = np.trunc(aa * 2.0**20) / 2.0**20
        cb = np.trunc(bb * 2.0**20) / 2.0**20
        parts_a.append(ca)
        parts_b.append(cb)
        aa, bb = (aa - ca) * 2.0**20, (bb - cb) * 2.0**20
    total = np.zeros((a.shape[0], b.shape[1]))
    correction = np.zeros_like(total)
    for degree in range(9):
        for i in range(5):
            j = degree - i
            if 0 <= j < 5:
                term = np.ldexp(parts_a[i] @ parts_b[j], -20 * degree)
                updated = total + term
                correction += np.where(abs(total) >= abs(term),
                                       (total - updated) + term,
                                       (term - updated) + total)
                total = updated
    return np.ldexp(total + correction, ea[:, None] + eb[None, :])


@lru_cache(maxsize=1)
def _native_kernel():
    features = np._core._multiarray_umath.__cpu_features__
    if not features.get("AVX512F") or not features.get("FMA3"):
        raise RuntimeError("the native kernel requires AVX512F and FMA3; use --backend portable")
    suffix = ".dll" if sys.platform == "win32" else ".dylib" if sys.platform == "darwin" else ".so"
    path = Path(__file__).resolve().parents[1] / "native" / ("compensated_dot" + suffix)
    if not path.is_file():
        raise FileNotFoundError("build the optional native kernel with build_native.py first")
    library = ctypes.CDLL(str(path))
    function = library.compensated_dot
    row_major = np.ctypeslib.ndpointer(dtype=np.float64, ndim=2, flags="C_CONTIGUOUS")
    column_major = np.ctypeslib.ndpointer(dtype=np.float64, ndim=2, flags="F_CONTIGUOUS")
    function.argtypes = [ctypes.c_int, ctypes.c_int, ctypes.c_int,
                         column_major, row_major, row_major]
    function.restype = None
    return library, function


def native_dot(a, b):
    """Use the AVX-512 reduction order of the manuscript implementation."""
    a, b = _check(a, b)
    ea = np.frexp(np.max(abs(a), axis=1))[1]
    eb = np.frexp(np.max(abs(b), axis=0))[1]
    if np.max(abs(ea)) <= 900 and np.max(abs(eb)) <= 900:
        aa = np.asfortranarray(a * np.ldexp(np.ones(len(ea)), -ea)[:, None])
        bb = np.ascontiguousarray(b * np.ldexp(np.ones(len(eb)), -eb)[None, :])
    else:
        aa = np.asfortranarray(np.ldexp(a, -ea[:, None]))
        bb = np.ascontiguousarray(np.ldexp(b, -eb[None, :]))
    out = np.empty((a.shape[0], b.shape[1]))
    _native_kernel()[1](a.shape[0], a.shape[1], b.shape[1], aa, bb, out)
    return np.ldexp(out, ea[:, None] + eb[None, :])


def get_product(backend):
    if backend == "portable":
        return portable_dot
    if backend == "native":
        _native_kernel()
        return native_dot
    raise ValueError("backend must be 'portable' or 'native'")
