"""Load channel inputs and compare computed arrays with archived outputs."""

import json
from pathlib import Path
import numpy as np
from .model import CoolingCase, Operators

DATA = Path(__file__).resolve().parents[1] / "data"


def load_cases():
    with np.load(DATA / "channel_operators.npz", allow_pickle=False) as archive:
        operators = Operators.from_archive(archive)
        x, y = archive["axial_grid"], archive["transverse_grid"]
    cases = [CoolingCase.from_record(r) for r in json.loads((DATA / "cases.json").read_text())]
    return operators, x, y, cases


def check_output(result, case, expected, operators):
    """Compare with stored experiment outputs; return absolute differences."""
    differences = {}
    for key, saved in (("coefficients", "coefficients"), ("q", "q"),
                       ("bulk", "bulk"), ("heat_integrals", "heat")):
        target = expected[f"{case.input_id}_{saved}"]
        np.testing.assert_allclose(result[key], target, rtol=2e-11, atol=2e-13)
        differences[key] = float(np.max(abs(result[key] - target)))
    field = expected[f"{case.input_id}_coefficients"] @ operators.query.T
    np.testing.assert_allclose(result["u"], field, rtol=2e-11, atol=2e-13)
    differences["u"] = float(np.max(abs(result["u"] - field)))
    return differences
