"""Channel inputs and the affine reduced operators."""

from dataclasses import dataclass
import numpy as np


@dataclass(frozen=True)
class CoolingCase:
    input_id: int
    epsilon: float
    slip: float
    biot: np.ndarray
    inlet_modes: np.ndarray

    def __post_init__(self):
        if not np.isfinite(self.epsilon) or self.epsilon <= 0:
            raise ValueError("epsilon must be finite and positive")
        if not np.isfinite(self.slip) or not 0 < self.slip <= 1:
            raise ValueError("slip must lie in (0, 1]")
        biot = np.asarray(self.biot, dtype=float).copy()
        inlet = np.asarray(self.inlet_modes, dtype=float).copy()
        if biot.shape != (8, 2) or not np.isfinite(biot).all() or np.any(biot <= 0):
            raise ValueError("biot must contain eight positive, finite two-wall pairs")
        if inlet.shape != (24,) or not np.isfinite(inlet).all():
            raise ValueError("inlet_modes must contain 24 finite sine coefficients")
        biot.setflags(write=False)
        inlet.setflags(write=False)
        object.__setattr__(self, "biot", biot)
        object.__setattr__(self, "inlet_modes", inlet)

    @classmethod
    def from_record(cls, record):
        return cls(*(record[k] for k in
                     ("input_id", "epsilon", "slip", "biot", "inlet_modes")))


@dataclass(frozen=True)
class Operators:
    mass0: np.ndarray
    massv: np.ndarray
    derivative_factor: np.ndarray
    walls: np.ndarray
    query: np.ndarray
    load0: np.ndarray
    loadv: np.ndarray

    @property
    def size(self):
        return len(self.mass0)

    @classmethod
    def from_archive(cls, archive):
        return cls(*(archive[k] for k in cls.__dataclass_fields__))


def segments(biot, axial_grid):
    """Assign a switching point to the segment on its left."""
    x = np.asarray(axial_grid, dtype=float)
    if (x.ndim != 1 or not len(x) or not np.isfinite(x).all()
            or np.any(x <= 0) or np.any(x > 1) or np.any(np.diff(x) <= 0)):
        raise ValueError("axial_grid must increase strictly within (0, 1]")
    for j, pair in enumerate(biot):
        left, right = j / len(biot), (j + 1) / len(biot)
        indices = np.flatnonzero((x > left) & (x <= right))
        yield j, pair, indices, x[indices] - left, right - left
