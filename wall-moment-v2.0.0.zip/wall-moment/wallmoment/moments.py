"""Mass-Schur selection of wall moments and teacher directions."""

import numpy as np
from scipy.linalg import cholesky, cho_solve, qr, solve_triangular, svd
from .model import Operators


def _schur_mass_solver(mass, protected):
    leading = mass[:protected, :protected]
    cross = mass[:protected, protected:]
    reverse_cross = mass[protected:, :protected]
    factor = cholesky(leading, lower=True)
    coupling = cho_solve((factor, True), cross)
    schur = mass[protected:, protected:] - reverse_cross @ coupling
    schur_factor = cholesky((schur + schur.T) / 2, lower=True)

    def solve(rhs):
        top = cho_solve((factor, True), rhs[:protected])
        tail = cho_solve((schur_factor, True), rhs[protected:] - reverse_cross @ top)
        return np.vstack((top - coupling @ tail, tail))

    complement = np.vstack((-coupling, np.eye(len(schur))))
    return solve, schur_factor, complement


def select_space(operators, teacher_factor, metric_factor, slip,
                 protected=115, retained=16):
    """Select four wall moments and twelve teacher directions at fixed velocity."""
    if not 0 < slip <= 1:
        raise ValueError("slip must lie in (0, 1]")
    if protected + 32 != operators.size or retained != 16:
        raise ValueError("expected a 115+32 mother space and 16 retained tails")

    mass = slip * operators.mass0 + (1 - slip) * operators.massv
    solve_mass, schur_factor, complement = _schur_mass_solver(
        (mass + mass.T) / 2, protected
    )
    tail_size = operators.size - protected
    wall_response = solve_mass(operators.walls.T)
    mandatory = np.empty((tail_size, 0))
    block_ranks = []

    for order in (0, 1):
        wall_response /= np.sqrt(np.sum(wall_response * (mass @ wall_response), axis=0))
        block = schur_factor.T @ wall_response[protected:]
        block /= np.linalg.norm(block, axis=0)
        for _ in range(2):
            block -= mandatory @ (mandatory.T @ block)
        vectors, singular_values, _ = svd(block, full_matrices=False,
                                          lapack_driver="gesvd")
        rank = int(np.sum(singular_values > 1e-10))
        if rank != 2:
            raise RuntimeError(f"wall-moment block {order} has rank {rank}")
        mandatory = np.column_stack((mandatory, vectors[:, :rank]))
        block_ranks.append(rank)
        if order == 0:
            stiffness_action = operators.derivative_factor.T @ (
                operators.derivative_factor @ wall_response
            )
            wall_response = solve_mass(stiffness_action)

    orthogonal, _ = qr(mandatory, mode="full")
    wall_part = orthogonal[:, :4]
    free_part = orthogonal[:, 4:]
    inverse_schur = solve_triangular(
        schur_factor.T, np.eye(tail_size), lower=False
    )
    teacher = free_part.T @ (schur_factor.T @ teacher_factor)
    metric = metric_factor @ complement @ inverse_schur @ free_part
    _, metric_triangular = qr(metric, mode="economic")
    left, singular_values, _ = svd(metric_triangular @ teacher,
                                   full_matrices=False, lapack_driver="gesvd")
    if len(singular_values) != tail_size - 4:
        raise RuntimeError("teacher factor does not span the complementary candidates")
    ranked = solve_triangular(metric_triangular, left)
    directions = inverse_schur @ np.column_stack(
        (wall_part, free_part @ ranked)
    )

    tails, _ = qr(directions[:, :retained], mode="economic")
    projection = np.zeros((operators.size, protected + retained))
    projection[:protected, :protected] = np.eye(protected)
    projection[protected:, protected:] = tails
    return projection, {"wall_moment_ranks": block_ranks,
                        "teacher_directions": retained - 4}


def project_operators(operators, projection):
    derivative = qr(operators.derivative_factor @ projection, mode="r")[0]
    size = projection.shape[1]
    return Operators(
        mass0=projection.T @ operators.mass0 @ projection,
        massv=projection.T @ operators.massv @ projection,
        derivative_factor=derivative[:size],
        walls=operators.walls @ projection,
        query=operators.query @ projection,
        load0=projection.T @ operators.load0,
        loadv=projection.T @ operators.loadv,
    )


