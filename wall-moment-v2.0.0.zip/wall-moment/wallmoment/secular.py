"""Positive rank-one eigensystem updates through LAPACK DLAED9."""
import ctypes as ct
import numpy as np
from scipy.linalg import cython_lapack

_name = ct.pythonapi.PyCapsule_GetName
_name.argtypes = [ct.py_object]
_name.restype = ct.c_char_p
_pointer = ct.pythonapi.PyCapsule_GetPointer
_pointer.argtypes = [ct.py_object, ct.c_char_p]
_pointer.restype = ct.c_void_p
_capsule = cython_lapack.__pyx_capi__['dlaed9']
_signature = _name(_capsule)
if not _signature.startswith(b'void (int *, int *, int *, int *,') or _signature.count(b'int *') != 7:
    raise RuntimeError('Unsupported SciPy DLAED9 C API signature')
_i = ct.POINTER(ct.c_int)
_d = ct.POINTER(ct.c_double)
_function = ct.CFUNCTYPE(None, _i, _i, _i, _i, _d, _d, _i, _d, _d, _d, _d, _i, _i)(
    _pointer(_capsule, _signature))


def positive_update(poles, vector, rho):
    poles = np.asarray(poles, dtype=np.float64)
    vector = np.asarray(vector, dtype=np.float64)
    n = len(poles)
    if (poles.ndim != 1 or vector.shape != poles.shape or n < 1 or
            not np.isfinite(poles).all() or not np.isfinite(vector).all() or
            not np.isfinite(rho) or rho < 0 or np.any(np.diff(poles) <= 0)):
        raise ValueError('Finite strictly ordered poles and nonnegative update required')
    norm = np.linalg.norm(vector)
    if rho == 0 or norm == 0:
        return poles.copy(), np.eye(n)
    # Exact zero components are deflated; no threshold discards small components.
    active = np.flatnonzero(vector != 0)
    if len(active) < n:
        values, vectors = positive_update(poles[active], vector[active], rho)
        full_values = poles.copy()
        full_vectors = np.eye(n)
        full_values[active] = values
        full_vectors[np.ix_(active, active)] = vectors
        order = np.argsort(full_values)
        return full_values[order], full_vectors[:, order]
    if n > np.iinfo(np.int32).max:
        raise ValueError('LAPACK integer overflow')
    d = np.empty(n)
    q = np.empty((n, n), order='F')
    s = np.empty((n, n), order='F')
    dlambda = poles.copy()
    w = vector / norm
    scale = ct.c_double(float(rho * norm * norm))
    size, first, info = ct.c_int(n), ct.c_int(1), ct.c_int()
    _function(ct.byref(size), ct.byref(first), ct.byref(size), ct.byref(size),
              d.ctypes.data_as(_d), q.ctypes.data_as(_d), ct.byref(size),
              ct.byref(scale), dlambda.ctypes.data_as(_d), w.ctypes.data_as(_d),
              s.ctypes.data_as(_d), ct.byref(size), ct.byref(info))
    if info.value or not np.isfinite(d).all() or not np.isfinite(s).all():
        raise FloatingPointError(f'DLAED9 failed: {info.value}')
    return d, s
