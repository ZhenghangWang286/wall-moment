"""Conservative propagation in the fixed 211-dimensional channel space."""

import numpy as np
from scipy.linalg import cholesky, qr, solve_triangular, svd
from threadpoolctl import ThreadpoolController
from .arithmetic import get_product
from .model import segments
from .secular import positive_update

_THREADS = ThreadpoolController()


def anchor_spectrum(factor):
    """Resolve the slow modes through the inverse of the triangular factor."""
    triangular = qr(factor, mode="r", check_finite=False)[0][:factor.shape[1]]
    inverse = solve_triangular(triangular, np.eye(len(triangular)), check_finite=False)
    vectors, singular, _ = svd(inverse, full_matrices=False, lapack_driver="gesdd")
    sigma = 1 / singular
    order = np.argsort(sigma)
    return sigma[order]**2, vectors[:, order]


def heat_from_moments(state_modes, operators, case, product):
    """Use weak tests 1 and y to recover both wall loads from moment decreases."""
    tests = case.slip * operators.load0[:, :2] + (1 - case.slip) * operators.loadv[:, :2]
    heat = []
    for mode, pair in zip(state_modes, case.biot):
        decreases = (-np.expm1(-mode["length"] * mode["rates"])) @ product(mode["amplitudes"], tests)
        upper = (decreases[1] + decreases[0] / pair[0]) / (1 + 1 / pair[0] + 1 / pair[1])
        heat.append([decreases[0] - upper, upper])
    return np.asarray(heat)


def direct_wall_heat(flux_modes):
    """Integrate the wall-flux modes independently of the weak identities."""
    values = []
    for mode in flux_modes:
        rates = mode["rates"]
        integral = np.full_like(rates, mode["length"])
        nonzero = rates != 0
        integral[nonzero] = -np.expm1(-mode["length"] * rates[nonzero]) / rates[nonzero]
        values.append(integral @ mode["amplitudes"])
    return np.asarray(values)


def solve_case(operators, case, axial_grid, backend="portable"):
    """Return field, wall flux, bulk moment, heat loads and modal coefficients.

    Both backends use the same reduced operators and propagation. The portable
    backend uses split products; the native backend uses the AVX-512 kernel.
    """
    steps = list(segments(case.biot, axial_grid))
    product = get_product(backend)

    def matvec(a, b):
        return product(a, np.asarray(b)[:, None])[:, 0]

    def triangular(a, b, lower, refine=False):
        value = solve_triangular(a, b, lower=lower)
        if refine:
            value += solve_triangular(a, b - product(a, value), lower=lower)
        return value

    with _THREADS.limit(limits=1, user_api="blas"):
        mass = case.slip * operators.mass0 + (1 - case.slip) * operators.massv
        factor = cholesky((mass + mass.T) / 2, lower=True)
        loads = case.slip * operators.load0 + (1 - case.slip) * operators.loadv
        rhs = product(loads, np.r_[1.0, 0.0, case.inlet_modes][:, None])
        state = triangular(factor, rhs, True, refine=True)[:, 0]
        walls = triangular(factor, operators.walls.T, True, refine=True).T
        derivative = triangular(factor, operators.derivative_factor.T, True).T
        anchor = np.min(case.biot, axis=0)
        poles, basis = anchor_spectrum(np.vstack((derivative, np.sqrt(anchor)[:, None] * walls)))
        wall_vectors = product(walls, basis)
        physical = triangular(factor.T, basis, False)
        state = matvec(basis.T, state)
        coefficients = np.empty((len(axial_grid), operators.size))
        flux_modes, state_modes = [], []
        energies, balance = [float(state @ state)], 0.0

        for _, pair, indices, ages, length in steps:
            eigenvalues, first = positive_update(poles, wall_vectors[0], float(pair[0] - anchor[0]))
            eigenvalues, second = positive_update(eigenvalues, matvec(first.T, wall_vectors[1]),
                                                 float(pair[1] - anchor[1]))
            vectors = first @ second
            modal_state = matvec(vectors.T, state)
            amplitudes = modal_state[:, None] * (physical @ vectors).T
            rates = case.epsilon * eigenvalues
            exponential = np.exp(-np.r_[ages, length][:, None] * rates)
            values = exponential @ amplitudes
            coefficients[indices] = values[:-1]
            flux_modes.append(dict(rates=rates, amplitudes=case.epsilon *
                                   (amplitudes @ operators.walls.T) * pair, length=length))
            state_modes.append(dict(rates=rates, amplitudes=amplitudes, length=length))
            derivative_x = -(exponential * rates) @ amplitudes
            residual = derivative_x @ loads[:, 0] + (case.epsilon * (values @ operators.walls.T) * pair).sum(axis=1)
            balance = max(balance, float(abs(residual).max()))
            state = matvec(vectors, np.exp(-length * rates) * modal_state)
            energies.append(float(state @ state))

        result = dict(
            u=coefficients @ operators.query.T,
            q=np.vstack([case.epsilon * (coefficients[ix] @ operators.walls.T) * pair
                         for _, pair, ix, _, _ in steps]),
            bulk=coefficients @ loads[:, 0], coefficients=coefficients,
            state_modes=state_modes, flux_modes=flux_modes, rank=operators.size,
            max_discrete_balance=balance,
            max_segment_energy_increase=float(max(0.0, np.diff(energies).max())),
        )
        result["heat_integrals"] = heat_from_moments(state_modes, operators, case, product)
        return result
