# Boundary-operator-guided wall-moment reduction and neural operator learning for switched thermal control

Code and numerical data accompanying this paper.

## Model

The wall-moment reduced model uses 131 directions for a channel with eight independently switched two-wall Robin segments. It retains a 115-dimensional coarse space and selects four velocity-dependent wall-adjoint directions and twelve teacher-informed directions from a 147-dimensional mother space. A single reduced temperature state propagates through all eight segments and yields wall flux, bulk temperature, temperature fields, and integrated segment heat loads.

Basis selection uses the velocity parameter, teacher covariance factor, and field-and-trace metric factor. Diffusion, Robin coefficients, and inlet amplitudes enter the reduced-model solve. The implementation includes the Schur-mass complement, first-order wall moments, teacher-factor compression, Galerkin projection, and square-root modal propagation.

## Repository contents

| Path | Contents |
| --- | --- |
| `wallmoment.py` | Model inputs, basis selection, operator projection, and segment propagation. |
| `data/operators.npz` | Mother operators, teacher covariance factor, field-and-trace metric factor, and evaluation grids. |
| `data/cases.json` | ID and OOD parameter inputs 748030003 and 748040003 from the paper's paired wall-flux figure. |
| `data/expected_outputs.npz` | Wall-flux, bulk-temperature, and segment-load outputs for numerical verification. |
| `data/paired_metrics.csv` | Paired wall-flux and temperature-field errors for the wall-moment ROM, POD139, and Rational131. |
| `run_inference.py` | Basis selection, reduced-model solves, and output verification for the supplied parameter inputs. |
| `plot_results.py` | Generates the paired wall-flux comparison figure from `data/paired_metrics.csv`. |
| `paired_flux.png` | Paired wall-flux comparison figure. |
| `tests/test_wallmoment.py` | Tests for numerical outputs, wall moments, basis selection, and comparison-table consistency. |
| `requirements.txt` | Pinned Python dependencies. |
| `SHA256SUMS` | SHA-256 file-integrity checksums. |

## Run

Use Python 3.12 and the dependency versions in `requirements.txt`. Run the following commands from the repository directory on Windows:

```text
python -m venv .venv
.venv\Scripts\python -m pip install -r requirements.txt
.venv\Scripts\python run_inference.py
.venv\Scripts\python -m unittest discover -s tests -v
.venv\Scripts\python plot_results.py
```

On macOS or Linux, use `.venv/bin/python` in place of `.venv\Scripts\python`.

The test file can also be run directly with `.venv\Scripts\python tests\test_wallmoment.py`.

The inference command prints the model dimensions, wall-moment ranks, teacher-direction count, balance residual, and a `PASS` result for each input. The test suite checks the reference outputs, energy decay, balance residuals, wall moments, basis construction, and comparison records. The plotting command regenerates `paired_flux.png`.

## Comparison data

`data/paired_metrics.csv` contains 32 paired inputs: 16 in-distribution (ID) and 16 out-of-distribution (OOD). Each row uses the same parameter input and reference for all three methods. The flux columns report all-age relative wall-flux $L^2$ errors; the field columns report relative temperature-field $L^2$ errors. All six error columns are dimensionless.

`plot_results.py` reads these comparison results and plots the wall-moment ROM against POD139 and Rational131, with ID and OOD inputs identified by distinct markers.
