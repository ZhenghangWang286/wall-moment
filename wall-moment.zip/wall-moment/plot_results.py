"""Plot paired wall-flux errors for the 32 comparison inputs."""

import csv
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np


ROOT = Path(__file__).resolve().parent
TABLE = ROOT / "data" / "paired_metrics.csv"


def main():
    with TABLE.open(encoding="utf-8", newline="") as stream:
        rows = list(csv.DictReader(stream))
    if len(rows) != 32 or {row["split"] for row in rows} != {"ID", "OOD"}:
        raise ValueError("expected 16 ID and 16 OOD paired inputs")

    plt.rcParams.update({"font.size": 8, "pdf.fonttype": 42})
    figure, axes = plt.subplots(1, 2, figsize=(7.2, 3.1), layout="constrained")
    comparisons = (("POD139", "pod139_flux_error"),
                   ("Rational131", "rational131_flux_error"))
    for axis, (label, column) in zip(axes, comparisons):
        compared = np.array([float(row[column]) for row in rows])
        proposed = np.array([float(row["proposed_flux_error"]) for row in rows])
        bounds = [min(compared.min(), proposed.min()) / 1.4,
                  max(compared.max(), proposed.max()) * 1.4]
        for split, color, marker in (("ID", "#16818b", "o"),
                                     ("OOD", "#b65e38", "^")):
            selected = [row for row in rows if row["split"] == split]
            x = np.array([float(row[column]) for row in selected])
            y = np.array([float(row["proposed_flux_error"]) for row in selected])
            axis.scatter(x, y, s=25, c=color, marker=marker, label=split)
        axis.plot(bounds, bounds, color="#293849", lw=0.8, ls="--")
        axis.set(xscale="log", yscale="log", xlim=bounds, ylim=bounds,
                 xlabel=f"{label} wall-flux error",
                 ylabel="Wall-moment ROM wall-flux error", title=label)
        axis.spines[["top", "right"]].set_visible(False)
    axes[0].legend(frameon=False)
    destination = ROOT / "paired_flux.png"
    figure.savefig(destination, dpi=300)
    plt.close(figure)
    print(f"Saved {destination}")


if __name__ == "__main__":
    main()
