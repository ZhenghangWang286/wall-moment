"""Run wall-moment inference and verify the numerical outputs."""

import json
from pathlib import Path

import numpy as np

from wallmoment import CoolingCase, Operators, project_operators, select_space, solve_case


DATA = Path(__file__).resolve().parent / "data"


def main():
    with np.load(DATA / "operators.npz", allow_pickle=False) as archive:
        operators = Operators.from_archive(archive)
        teacher = archive["teacher_factor"]
        metric = archive["metric_factor"]
        axial_grid = archive["axial_grid"]
    cases = json.loads((DATA / "cases.json").read_text(encoding="utf-8"))

    with np.load(DATA / "expected_outputs.npz", allow_pickle=False) as expected:
        for record in cases:
            case = CoolingCase.from_record(record)
            projection, construction = select_space(
                operators, teacher, metric, case.slip
            )
            reduced = project_operators(operators, projection)
            result = solve_case(reduced, case, axial_grid)
            for name in ("wall_flux", "bulk_temperature", "segment_heat"):
                reference = expected[f"{case.input_id}_{name}"]
                if not np.allclose(result[name], reference, rtol=1e-9, atol=1e-11):
                    raise AssertionError(f"{case.input_id}: {name} differs from expected output")
            if result["max_energy_increase"] > 1e-12:
                raise AssertionError(f"{case.input_id}: energy increased")
            print(
                f"{case.input_id}: {operators.size} -> {reduced.size} directions; "
                f"wall blocks {construction['wall_moment_ranks']}; "
                f"{construction['teacher_directions']} teacher directions; "
                f"max balance residual {result['max_balance_residual']:.3e}; PASS"
            )


if __name__ == "__main__":
    main()
