import csv
import json
import sys
import unittest
from pathlib import Path

import numpy as np
from scipy.linalg import cholesky, qr, solve_triangular

ROOT = Path(__file__).resolve().parents[1]
if __name__ == "__main__":
    sys.path.insert(0, str(ROOT))

from wallmoment import CoolingCase, Operators, project_operators, select_space, solve_case


DATA = ROOT / "data"


class WallMomentTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        with np.load(DATA / "operators.npz", allow_pickle=False) as archive:
            cls.operators = Operators.from_archive(archive)
            cls.teacher = archive["teacher_factor"]
            cls.metric = archive["metric_factor"]
            cls.axial_grid = archive["axial_grid"]
        cls.cases = [CoolingCase.from_record(record) for record in json.loads(
            (DATA / "cases.json").read_text(encoding="utf-8")
        )]

    def test_expected_outputs(self):
        with np.load(DATA / "expected_outputs.npz", allow_pickle=False) as expected:
            for case in self.cases:
                with self.subTest(input_id=case.input_id):
                    projection, info = select_space(
                        self.operators, self.teacher, self.metric, case.slip
                    )
                    self.assertEqual(projection.shape, (147, 131))
                    self.assertEqual(info["wall_moment_ranks"], [2, 2])
                    self.assertEqual(info["teacher_directions"], 12)
                    result = solve_case(
                        project_operators(self.operators, projection),
                        case, self.axial_grid,
                    )
                    for name in ("wall_flux", "bulk_temperature", "segment_heat"):
                        np.testing.assert_allclose(
                            result[name], expected[f"{case.input_id}_{name}"],
                            rtol=1e-9, atol=1e-11,
                        )
                    self.assertLessEqual(result["max_energy_increase"], 1e-12)
                    self.assertLess(result["max_balance_residual"], 1e-9)

    def test_common_wall_moments(self):
        for case in self.cases:
            projection, _ = select_space(
                self.operators, self.teacher, self.metric, case.slip
            )
            mass = case.slip * self.operators.mass0 + (
                1 - case.slip
            ) * self.operators.massv
            factor = cholesky(mass, lower=True)
            retained, _ = qr(factor.T @ projection, mode="economic")
            discarded = np.eye(147) - retained @ retained.T
            inverse = solve_triangular(factor, np.eye(147), lower=True)
            for segment, biot in enumerate(case.biot):
                with self.subTest(input_id=case.input_id, segment=segment):
                    stiffness = (
                        self.operators.derivative_factor.T
                        @ self.operators.derivative_factor
                        + self.operators.walls.T @ np.diag(biot)
                        @ self.operators.walls
                    )
                    generator = case.epsilon * inverse @ stiffness @ inverse.T
                    output = (
                        case.epsilon * np.diag(biot)
                        @ self.operators.walls @ inverse.T
                    )
                    zero_order = np.linalg.norm(output @ discarded) / np.linalg.norm(output)
                    first_order = np.linalg.norm(output @ generator @ discarded) / np.linalg.norm(output @ generator)
                    self.assertLess(zero_order, 1e-12)
                    self.assertLess(first_order, 1e-12)

    def test_selector_depends_only_on_velocity_and_offline_factors(self):
        case = self.cases[0]
        first, _ = select_space(
            self.operators, self.teacher, self.metric, case.slip
        )
        second, _ = select_space(
            self.operators, self.teacher, self.metric, case.slip
        )
        np.testing.assert_array_equal(first, second)
        np.testing.assert_array_equal(first[:115, :115], np.eye(115))
        np.testing.assert_array_equal(first[:115, 115:], np.zeros((115, 16)))

    def test_paired_record_count(self):
        with (DATA / "paired_metrics.csv").open(encoding="utf-8", newline="") as stream:
            records = list(csv.DictReader(stream))
        self.assertEqual(len(records), 32)
        self.assertEqual(sum(row["split"] == "ID" for row in records), 16)
        self.assertEqual(sum(row["split"] == "OOD" for row in records), 16)
        for row in records:
            proposed = float(row["proposed_flux_error"])
            self.assertLess(proposed, float(row["pod139_flux_error"]))
            self.assertLess(proposed, float(row["rational131_flux_error"]))


if __name__ == "__main__":
    unittest.main()
