"""Wall-moment reduction for the switched two-wall cooling model."""

from dataclasses import dataclass

import numpy as np
from scipy.linalg import cholesky, cho_solve, qr, solve_triangular, svd


@dataclass(frozen=True)
class CoolingCase:
    input_id: int
    epsilon: float
    slip: float
    biot: np.ndarray
    inlet_modes: np.ndarray

    @classmethod
    def from_record(cls, record):
        case = cls(
            input_id=int(record["input_id"]),
            epsilon=float(record["epsilon"]),
            slip=float(record["slip"]),
            biot=np.asarray(record["biot"], dtype=float),
            inlet_modes=np.asarray(record["inlet_modes"], dtype=float),
        )
        if not (case.epsilon > 0 and 0 < case.slip <= 1):
            raise ValueError("epsilon must be positive and slip must lie in (0, 1]")
        if case.biot.shape != (8, 2) or np.any(case.biot <= 0):
            raise ValueError("biot must contain eight positive two-wall pairs")
        if case.inlet_modes.shape != (24,):
            raise ValueError("the inlet must have 24 sine coefficients")
        return case


@dataclass(frozen=True)
class Operators:
    mass0: np.ndarray
    massv: np.ndarray
    derivative_factor: np.ndarray
    walls: np.ndarray
    query: np.ndarray
    load0: np.ndarray
    loadv: np.ndarray

    @property
    def size(self):
        return self.mass0.shape[0]

    @classmethod
    def from_archive(cls, archive):
        return cls(*(archive[name] for name in (
            "mass0", "massv", "derivative_factor", "walls", "query",
            "load0", "loadv",
        )))


def _schur_mass_solver(mass, protected):
    leading = mass[:protected, :protected]
    cross = mass[:protected, protected:]
    reverse_cross = mass[protected:, :protected]
    factor = cholesky(leading, lower=True)
    coupling = cho_solve((factor, True), cross)
    schur = mass[protected:, protected:] - reverse_cross @ coupling
    schur_factor = cholesky((schur + schur.T) / 2, lower=True)

    def solve(rhs):
        top = cho_solve((factor, True), rhs[:protected])
        tail = cho_solve((schur_factor, True), rhs[protected:] - reverse_cross @ top)
        return np.vstack((top - coupling @ tail, tail))

    complement = np.vstack((-coupling, np.eye(len(schur))))
    return solve, schur_factor, complement


def select_space(operators, teacher_factor, metric_factor, slip,
                 protected=115, retained=16):
    """Select four wall moments and twelve teacher directions at fixed velocity."""
    if not 0 < slip <= 1:
        raise ValueError("slip must lie in (0, 1]")
    if protected + 32 != operators.size or retained != 16:
        raise ValueError("expected a 115+32 mother space and 16 retained tails")

    mass = slip * operators.mass0 + (1 - slip) * operators.massv
    solve_mass, schur_factor, complement = _schur_mass_solver(
        (mass + mass.T) / 2, protected
    )
    tail_size = operators.size - protected
    wall_response = solve_mass(operators.walls.T)
    mandatory = np.empty((tail_size, 0))
    block_ranks = []

    for order in (0, 1):
        wall_response /= np.sqrt(np.sum(wall_response * (mass @ wall_response), axis=0))
        block = schur_factor.T @ wall_response[protected:]
        block /= np.linalg.norm(block, axis=0)
        for _ in range(2):
            block -= mandatory @ (mandatory.T @ block)
        vectors, singular_values, _ = svd(block, full_matrices=False,
                                          lapack_driver="gesvd")
        rank = int(np.sum(singular_values > 1e-10))
        if rank != 2:
            raise RuntimeError(f"wall-moment block {order} has rank {rank}")
        mandatory = np.column_stack((mandatory, vectors[:, :rank]))
        block_ranks.append(rank)
        if order == 0:
            stiffness_action = operators.derivative_factor.T @ (
                operators.derivative_factor @ wall_response
            )
            wall_response = solve_mass(stiffness_action)

    orthogonal, _ = qr(mandatory, mode="full")
    wall_part = orthogonal[:, :4]
    free_part = orthogonal[:, 4:]
    inverse_schur = solve_triangular(
        schur_factor.T, np.eye(tail_size), lower=False
    )
    teacher = free_part.T @ (schur_factor.T @ teacher_factor)
    metric = metric_factor @ complement @ inverse_schur @ free_part
    _, metric_triangular = qr(metric, mode="economic")
    left, singular_values, _ = svd(metric_triangular @ teacher,
                                   full_matrices=False, lapack_driver="gesvd")
    if len(singular_values) != tail_size - 4:
        raise RuntimeError("teacher factor does not span the complementary candidates")
    ranked = solve_triangular(metric_triangular, left)
    directions = inverse_schur @ np.column_stack(
        (wall_part, free_part @ ranked)
    )

    tails, _ = qr(directions[:, :retained], mode="economic")
    projection = np.zeros((operators.size, protected + retained))
    projection[:protected, :protected] = np.eye(protected)
    projection[protected:, protected:] = tails
    return projection, {"wall_moment_ranks": block_ranks,
                        "teacher_directions": retained - 4}


def project_operators(operators, projection):
    derivative = qr(operators.derivative_factor @ projection, mode="r")[0]
    size = projection.shape[1]
    return Operators(
        mass0=projection.T @ operators.mass0 @ projection,
        massv=projection.T @ operators.massv @ projection,
        derivative_factor=derivative[:size],
        walls=operators.walls @ projection,
        query=operators.query @ projection,
        load0=projection.T @ operators.load0,
        loadv=projection.T @ operators.loadv,
    )


def _decay_integral(rates, length):
    result = np.full_like(rates, length)
    positive = rates > 0
    result[positive] = -np.expm1(-length * rates[positive]) / rates[positive]
    return result


def solve_case(operators, case, axial_grid):
    """Propagate one Galerkin state through all eight Robin segments."""
    x = np.asarray(axial_grid, dtype=float)
    if x.ndim != 1 or np.any(x <= 0) or np.any(x > 1) or np.any(np.diff(x) <= 0):
        raise ValueError("axial_grid must be strictly increasing in (0, 1]")

    mass = case.slip * operators.mass0 + (1 - case.slip) * operators.massv
    factor = cholesky((mass + mass.T) / 2, lower=True)
    inverse_transpose = solve_triangular(
        factor.T, np.eye(operators.size), lower=False
    )
    loads = case.slip * operators.load0 + (1 - case.slip) * operators.loadv
    inlet = np.r_[1.0, 0.0, case.inlet_modes]
    state = inverse_transpose.T @ loads @ inlet
    wall_factor = operators.walls @ inverse_transpose
    derivative = operators.derivative_factor @ inverse_transpose

    coefficients = np.empty((len(x), operators.size))
    wall_flux = np.empty((len(x), 2))
    segment_heat = np.empty((8, 2))
    energies = [float(state @ state)]
    balance = 0.0

    for segment, biot in enumerate(case.biot):
        start, end = segment / 8, (segment + 1) / 8
        indices = np.flatnonzero((x > start) & (x <= end))
        ages = x[indices] - start
        _, singular_values, right = svd(
            np.vstack((derivative, np.sqrt(biot)[:, None] * wall_factor)),
            full_matrices=False, lapack_driver="gesvd",
        )
        eigenvectors = right.T
        rates = case.epsilon * singular_values**2
        modal_state = eigenvectors.T @ state
        amplitudes = modal_state[:, None] * (inverse_transpose @ eigenvectors).T
        temperatures = np.exp(-np.r_[ages, end - start][:, None] * rates) @ amplitudes
        coefficients[indices] = temperatures[:-1]
        wall_flux[indices] = case.epsilon * (
            temperatures[:-1] @ operators.walls.T
        ) * biot
        wall_amplitudes = case.epsilon * (amplitudes @ operators.walls.T) * biot
        segment_heat[segment] = _decay_integral(rates, end - start) @ wall_amplitudes

        axial_derivative = -(
            np.exp(-np.r_[ages, end - start][:, None] * rates) * rates
        ) @ amplitudes
        local_balance = np.abs(
            axial_derivative @ loads[:, 0]
            + (case.epsilon * (temperatures @ operators.walls.T) * biot).sum(axis=1)
        )
        balance = max(balance, float(local_balance.max()))
        state = eigenvectors @ (np.exp(-(end - start) * rates) * modal_state)
        energies.append(float(state @ state))

    return {
        "wall_flux": wall_flux,
        "bulk_temperature": coefficients @ loads[:, 0],
        "segment_heat": segment_heat,
        "field": coefficients @ operators.query.T,
        "max_energy_increase": float(max(0.0, np.diff(energies).max())),
        "max_balance_residual": balance,
    }
